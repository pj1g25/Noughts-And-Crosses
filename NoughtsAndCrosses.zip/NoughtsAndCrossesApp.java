package lecture1;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class NoughtsAndCrossesApp extends Application {

    private int grid_size;
    private double windowWidth = 650;
    private double windowHeight = 650;
    private GameBoard gameBoard;
    private BorderPane root = new BorderPane();
    private HBox bottomBox = new HBox();
    private Button[][] buttons;
    private Text xName = new Text();
    private Text oName = new Text();
    private BorderPane gameOverRoot = new BorderPane();
    BorderPane loadingRoot = new BorderPane();
    private int xNumOfWins = 0;
    private int oNumOfWins = 0;
    private int draws = 0;

    @Override
    public void start(Stage stage){

        GridPane grid = new GridPane();
        grid.setMaxSize(500, 500);
        grid.setStyle("-fx-background-color: black;");
        grid.setHgap(10);
        grid.setVgap(10);


        TextField gridSizeInput = new TextField();
        gridSizeInput.setMaxWidth(50);
        grid_size = 3;

        gridSizeInput.textProperty().addListener((obs, oldVal, newVal) -> {
            try {
                grid_size = Integer.parseInt(newVal);
            } catch (NumberFormatException e) {
                System.out.println("only integers");
            }
        });

        TextField player1Name =  new TextField();
        TextField player2Name =  new TextField();
        player1Name.setMaxWidth(100);
        player2Name.setMaxWidth(100);

        Text enterNameX = new Text("enter player X name");
        Text enterNameO = new Text("enter player O name");


        player1Name.textProperty().addListener((obs, oldVal, newVal) -> {
            try {
                player1Name.setText(newVal);
            } catch (Exception e) {
                System.out.println(e);
            }
            xName = new Text(player1Name.getText());
        });

        player2Name.textProperty().addListener((obs, oldVal, newVal) -> {
            try {
                player2Name.setText(newVal);
            } catch (Exception e) {
                System.out.println(e);
            }
            oName = new Text(player2Name.getText());
        });



        Button resetBtn = new Button("reset");
        resetBtn.setOnAction(e -> handleReset());
        resetBtn.setTranslateY(20);
        resetBtn.setStyle("-fx-background-color: rgb(255, 255, 255); -fx-font-size: 15px;");

        root.setCenter(grid);
        grid.setAlignment(Pos.CENTER);

        HBox topBox = new HBox();
        topBox.setAlignment(Pos.CENTER);
        topBox.getChildren().add(resetBtn);
        root.setTop(topBox);

        bottomBox.setAlignment(Pos.CENTER);
        root.setBottom(bottomBox);

        root.setStyle("-fx-background-color: rgb(144, 99, 255);");
        Scene playScene = new Scene(root, windowWidth, windowHeight);

        Button playBtn = new Button("Play");
        playBtn.setOnAction(e -> {
            if (!xName.getText().isEmpty() && !oName.getText().isEmpty()) {
                if (gameBoard == null) {
                    gameBoard = new GameBoard(grid_size);
                    buttons = new Button[grid_size][grid_size];
                    createGrid(grid);
                    showNames();
                }
                stage.setScene(playScene);
            }
        });

        HBox bottomLoadBox = new HBox();
        bottomLoadBox.setAlignment(Pos.CENTER);
        bottomLoadBox.getChildren().add(playBtn);
        loadingRoot.setBottom(bottomLoadBox);
        playBtn.setTranslateY(-70);
        playBtn.setTranslateX(40);

        VBox playersNames = new VBox();
        playersNames.setAlignment(Pos.TOP_CENTER);
        playersNames.getChildren().add(player1Name);
        player1Name.setTranslateY(50);
        playersNames.getChildren().add(enterNameX);
        playersNames.getChildren().add(enterNameO);
        enterNameO.setTranslateY(70);
        playersNames.getChildren().add(player2Name);
        player2Name.setTranslateY(80);

        loadingRoot.setTop(playersNames);

        Text enterGridSize = new Text("enter grid size");
        playersNames.getChildren().add(enterGridSize);
        enterGridSize.setTranslateY(240);

        Button scoreBtn = new Button("Score Board");
        scoreBtn.setOnAction(e -> {
            Stage scoreStage = new Stage();
            BorderPane scoreRoot = new BorderPane();
            Text scoreText = new Text("X wins: " + xNumOfWins + "     O wins: "  + oNumOfWins + "     draws: " + draws);
            scoreText.setStyle("-fx-font-size: 30px; -fx-font-weight: bold;");
            HBox scores = new HBox();
            scores.setAlignment(Pos.CENTER);
            scores.getChildren().add(scoreText);
            scoreRoot.setCenter(scores);

            Scene scoreScene = new Scene(scoreRoot, 600, 300);
            scoreStage.setScene(scoreScene);
            scoreStage.show();
        });

        bottomLoadBox.getChildren().add(scoreBtn);
        scoreBtn.setTranslateY(-70);
        scoreBtn.setTranslateX(200);



        loadingRoot.setCenter(gridSizeInput);
        Scene loadingScene = new Scene(loadingRoot, windowWidth, windowHeight);
        stage.setScene(loadingScene);

        Button exitBtn = new Button("Exit");
        exitBtn.setOnAction(e -> {
            stage.setScene(loadingScene);

        });

        topBox.getChildren().add(exitBtn);
        exitBtn.setTranslateY(20);
        exitBtn.setTranslateX(-250);
        exitBtn.setStyle("-fx-background-color: rgb(255, 255, 255); -fx-font-size: 15px;");
        root.setTop(topBox);


        stage.show();
    }

    public void handleMove(Button button, int row, int col){
        String winner = gameBoard.checkWinner();
        if(gameBoard.makeMove(row, col) && winner.isEmpty()) {
            button.setText(gameBoard.currentPlayer);
            gameBoard.switchPlayer();
            showNames();
            winner = gameBoard.checkWinner();
            bottomBox.getChildren().clear();
        }

        boolean full= true;
        for (int i =0; i<grid_size; i++){
            for (int j =0; j<grid_size; j++){
                if(buttons[i][j].getText().equals("")){
                    full = false;
                }
            }
        }

        if(!winner.isEmpty() || full){
            Text winnerText;
            if (!full) {
                winnerText = new Text(winner + " wins !");
                if (winner.equals("X")){
                    xNumOfWins++;
                }else if (winner.equals("O")){
                    oNumOfWins++;
                }
            }else {
                winnerText = new Text("Draw");
                draws++;
            }
            winnerText.setStyle("-fx-font-size: 50px; -fx-font-weight: bold;");
            HBox winnerBox = new HBox();
            winnerBox.getChildren().add(winnerText);
            winnerBox.setAlignment(Pos.CENTER);
            gameOverRoot.setCenter(winnerBox);
            Stage gameOverstage = new Stage();
            gameOverstage.setScene(new Scene(gameOverRoot, 300, 100));
            gameOverstage.show();
        };


    }


    public  void handleReset(){
        gameBoard.resetBoard();
        for (int i = 0; i<grid_size; i++){
            for (int j =0; j<grid_size; j++){
                buttons[i][j].setText("");
                showNames();
            }
        }
        bottomBox.getChildren().clear();
    }


    public void createGrid(GridPane grid){
        for (int row = 0; row < grid_size; row++) {
            for (int col = 0; col < grid_size; col++) {
                Button button = new Button();
                buttons[row][col] = button;
                button.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);

                int finalRow = row;
                int finalCol = col;
                button.setOnAction(e -> handleMove(button, finalRow, finalCol));
                button.setStyle("-fx-background-color: rgb(255, 255, 255); -fx-font-size: 20px;");
                button.setText("");

                grid.add(button, col, row);
                grid.setHalignment(button, HPos.CENTER);
                grid.setValignment(button, VPos.CENTER);
            }
        }

        for (int i =0; i<grid_size; i++){
            ColumnConstraints column = new ColumnConstraints();
            column.setPercentWidth(windowWidth/grid_size);
            RowConstraints row = new RowConstraints();
            row.setPercentHeight(windowHeight/grid_size);
            grid.getColumnConstraints().add(column);
            grid.getRowConstraints().add(row);

        }
    }

    public void showNames(){
        HBox names = new HBox();
        names.setAlignment(Pos.CENTER);
        names.getChildren().clear();
        if(gameBoard.getCurrentPlayer().equals("X")){
            names.getChildren().add(xName);
            xName.setTranslateX(-70);
            xName.setTranslateY(-20);
            xName.setStyle("-fx-font-size: 30px; -fx-font-weight: bold;");
        }else{
            names.getChildren().add(oName);
            oName.setTranslateX(70);
            oName.setTranslateY(-20);
            oName.setStyle("-fx-font-size: 30px; -fx-font-weight: bold;");
        }

        root.setBottom(names);

    };



    public static void main(String[] args) {
        launch();
    }
}
