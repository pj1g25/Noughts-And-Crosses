package lecture1;

public class GameBoard {
    int size;
    String[][] board;
    String currentPlayer;

    public GameBoard(int size) {
        this.size = size;
        board = new String[size][size];
        for (int i =0; i<size; i++){
            for  (int j =0; j<size; j++){
                board[i][j] = "";
            }
        }

        currentPlayer = "X";
    }

    public String getCurrentPlayer(){
        return currentPlayer;
    }

    public void resetBoard(){
        for (int i =0; i<size; i++){
            for  (int j =0; j<size; j++){
                board[i][j] = "";
            }
        }
        currentPlayer = "X";
    }

    public void switchPlayer(){
        if (currentPlayer.equals("X")){
            currentPlayer = "O";
        }else if  (currentPlayer.equals("O")){
            currentPlayer = "X";
        }
    }

    public boolean makeMove(int row, int col){
        if (board[row][col].isEmpty()){
            board[row][col] = currentPlayer;
            return true;
        }else{
            return false;
        }
    }

    public String checkWinner(){
        /*for(int i =0; i<size; i++){
            if (board[i][0].equals(board[i][1]) && board[i][0].equals(board[i][2])){
                return board[i][0];
            }
        }

        for (int j =0; j<size; j++){
            if (board[0][j].equals(board[1][j]) && board[0][j].equals(board[2][j])){
                return board[0][j];
            }
        }

        if  (board[0][0].equals(board[1][1]) && board[0][0].equals(board[2][2])){
            return board[0][0];
        }

        if (board[0][2].equals(board[1][1]) && board[0][2].equals(board[2][0])) {
            return board[0][2];
            // CHANGE THIS SO THAT IT WORKS FOR ANY SIZE GRID
        }

        return "";*/

        String winnerH= "";
        int i = 0;
        while(i <size && winnerH.isEmpty()){
            winnerH = checkArray(board[i]);
            i++;
        }

        String winnerV = "";
        i = 0;
        String[] symbols = new String[size];
        while(i<size && winnerV.isEmpty()){
            for(int j=0; j<size; j++){
                symbols[j] = board[j][i];
            }
            winnerV = checkArray(symbols);
            i++;
        }

        for(i = 0; i<size; i++){
            symbols[i] = board[i][i];
        }
        String winnerDL = checkArray(symbols);

        for (i= 0; i<size; i++){
            symbols[i] =board[i][size-i-1];
        }
        String winnerDR = checkArray(symbols);

        if(!winnerH.isEmpty()){
            return winnerH;
        }else if(!winnerV.isEmpty()) {
            return winnerV;
        }else if(!winnerDL.isEmpty()) {
            return winnerDL;
        }else if (!winnerDR.isEmpty()){
            return winnerDR;
        }else{
            return "";
        }

    }

    String checkArray(String[] array){
        boolean stillEqual = true;
        for(int i =1; i<size; i++){
            if (!array[i].equals(array[i-1])){
                stillEqual = false;
            }
        }
        if (stillEqual && !array[0].isEmpty()){
                return array[0];
        }
        return "";
    }
}
